﻿using System;

namespace Ü111152BHEL
{
    class Program
    {
        static void Main(string[] args)
        {

            double Länge, Breite, Fläche, Umfang;
            string widerholen;


            Console.WriteLine("Xxx Rechteck xxX");
            do
            {


                do
                {
                    Console.Write("Bitte geben sie die Länge: ");
                    Länge = Convert.ToDouble(Console.ReadLine());
                }
                while (Länge <= 0);

                do
                {
                    Console.Write("Bitte geben sie die Breite: ");
                    Breite = Convert.ToDouble(Console.ReadLine());
                }
                while (Breite <= 0);

                Fläche = Länge * Breite;
                Umfang = 2 * Länge + 2 * Breite;
                Console.WriteLine("Die Fläche beträgt: " + Fläche);
                Console.WriteLine("Der Umfang beträgt: " + Umfang);
                Console.Write("Wollen sie das Program widerholen [J/N] :");
                widerholen = Console.ReadLine();
                widerholen = widerholen.ToUpper();               

            } while (widerholen == "JA" || widerholen == "J");

            Console.ReadLine();
                

                



                



        }
    }
}

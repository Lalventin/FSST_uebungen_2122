﻿using System;

namespace Ü19152BHEL
{
    class Program
    {
        static void Main(string[] args)
        {
            int Summe, counter;
            string antwort, tmp_str;

            Console.WriteLine("Summe bis ende");

            do
            {
                Summe = 0;
                counter = 0;
                do
                {
                    Console.Write("Bitte geben sie eine ganze Zahl ein: ");
                    tmp_str = Console.ReadLine();
                    if(tmp_str == "ENDE")
                    {
                        break;
                    }
                    else
                    {
                        Summe += Convert.ToInt32(tmp_str);
                        counter++;
                    }
                } while (true);                
                Console.WriteLine($"Die Summe beträgt : {Summe}");


                Console.Write("Wollen sie das Programm widerholen [N/j] : ");
                antwort = Console.ReadLine();
                antwort = antwort.ToUpper();
            } while (antwort == "JA" || antwort == "J");

            Console.ReadLine();
        }
    }
}
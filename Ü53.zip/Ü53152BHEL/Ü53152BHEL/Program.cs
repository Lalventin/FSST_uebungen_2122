﻿using System;

namespace Ü53152BHEL
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Meinlesen_ganz(0, 10));
            Console.WriteLine(Meinlesen_dezimal(0.5, 10.2));
        }
        static int Meinlesen_ganz(int UG, int OG)
        {
            int Eingabe = 0;
            bool widerholen = true;
            do
            {
                Console.Write("Bitte geben sie eine ganze Zahl ein: ");
                try
                {
                    Eingabe = Convert.ToInt32(Console.ReadLine());
                    if(Eingabe < UG || Eingabe > OG)
                    {
                        widerholen = true;
                        Console.WriteLine("Zahl nicht im gewünschten Bereich!");
                    }
                    else
                    {
                        widerholen = false;
                        
                    }
                    
                }
                catch(Exception e)
                {
                    Console.WriteLine("Eingabe nicht korrekt.");
                }
                
            }while(widerholen == true);
            return Eingabe;
        }
        static double Meinlesen_dezimal(double UG, double OG)
        {
            double Eingabe = 0;
            bool widerholen = true;
            do
            {
                Console.Write("Bitte geben sie eine Zahl ein: ");
                try
                {
                    Eingabe = Convert.ToDouble(Console.ReadLine());
                    if (Eingabe < UG || Eingabe > OG)
                    {
                        widerholen = true;
                        Console.WriteLine("Zahl nicht im gewünschten Bereich!");
                    }
                    else
                    {
                        widerholen = false;

                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine("Eingabe nicht korrekt.");
                }

            } while (widerholen == true);
            return Eingabe;
        }
    }
}

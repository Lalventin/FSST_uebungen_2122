﻿using System;

namespace Ü38152BHEL
{
    internal class Program
    {
        static void Main(string[] args)
        {//JISA
            string[] Notennamen = new string[7];//definition Schulfächer
            Notennamen[0] = "Deutschnote";
            Notennamen[1] = "Mathematiknote";
            Notennamen[2] = "Englischnote";
            Notennamen[3] = "Hardwareentwicklung";
            Notennamen[4] = "Fachspezifische Software Technik";
            Notennamen[5] = "Religion";
            Notennamen[6] = "Bewegung und Sport";

            double Durchschnitt_Schüler;
            int[] Klassendurchschnitte = new int[7];//gleiche Fächerreihenfolge wie bei "Notennamen"

            string[,] Namen_Schüler = new string[36, 2]; //Zeile 0: Nachname, Zeile 1: Vorname
            int Anzahl_Schüler, Durchschnitt_Schüler_Berechnung, Durchschnitt_Schüler_Tmp;

            do
            {
                for (int x = 0; x <= 6; x++)
                {
                    Klassendurchschnitte[x] = 0;
                }
                Durchschnitt_Schüler_Berechnung = 0;

                Anzahl_Schüler = Einlesen_OGUG("Schüleranzahl ", 0, 36);

                for (int Schüler_index = 0; Schüler_index < Anzahl_Schüler; Schüler_index++)
                {

                    Console.WriteLine("Geben sie bitte die Datei für Schüler Katalog Nr. " + (Schüler_index + 1) + "ein: ");
                    Console.Write("Familienname: ");
                    Namen_Schüler[Schüler_index, 0] = Console.ReadLine();
                    Console.Write("Vorname: ");
                    Namen_Schüler[Schüler_index, 1] = Console.ReadLine();

                    for (int Notenindex = 0; Notenindex <= 6; Notenindex++)
                    {

                        Durchschnitt_Schüler_Tmp = Einlesen_OGUG($"{Notennamen[Notenindex]} : ", 0, 5);
                        Durchschnitt_Schüler_Berechnung += Durchschnitt_Schüler_Tmp; //berechnung Durchschnitt des Schülers
                        Klassendurchschnitte[Notenindex] += Durchschnitt_Schüler_Tmp;//Speichern Klassendurchschnitte bei Fach i
                    }
                    Durchschnitt_Schüler = Convert.ToDouble(Durchschnitt_Schüler_Berechnung) / 7.0;//berechnen Durchschnitt Schüler
                    Console.WriteLine("Der Durchschnitt von Katalognummer: " + (Schüler_index + 1) + " " + Namen_Schüler[Schüler_index, 0] + " " + Namen_Schüler[Schüler_index, 1] + " beträgt: " + Durchschnitt_Schüler);
                    Durchschnitt_Schüler = 0;
                    Durchschnitt_Schüler_Berechnung = 0;

                }
                for (int y = 0; y <= 6; y++)
                {
                    Console.WriteLine("Der Notendurchschnitt in " + Notennamen[y] + " beträgt für die Klasse: " + ((double)Klassendurchschnitte[y] / (double)Anzahl_Schüler));
                }
            } while (MWiderholen() == true);
        }
        static bool MWiderholen()
        {
            string einlesen;
            bool widerholen;
            Console.Write("Wollen sie das Programm widerholen [j/N] : ");
            einlesen = Console.ReadLine().ToUpper();
            if (einlesen == "JA" || einlesen == "J")
            {
                widerholen = true;
            }
            else
            {
                widerholen = false;
            }
            return widerholen;
        }
        static int Einlesen_OGUG(string Name, int UG, int OG)
        {
            int Eingabe;
            do
            {
                Console.Write($"Bitte geben sie die {Name} ein: ");
                Eingabe = Convert.ToInt32(Console.ReadLine());
            } while (Eingabe < UG || Eingabe > OG);
            return Eingabe;
        }
    }
}

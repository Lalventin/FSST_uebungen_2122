﻿using System;

namespace Ü39152BHEL
{
    internal class Program
    {
        static void Main(string[] args)
        {//JISA
            int Summe, counter;
            string tmp_str;
            do
            {
                Summe = 0;
                counter = 0;
                while (true)
                {
                    tmp_str = Input_String("Bitte geben sie eine ganze Zahl ein: ");
                    if(tmp_str.ToUpper() == "ENDE")
                    {
                        break;
                    }
                    else
                    {
                        Summe += Convert.ToInt32(tmp_str);
                        counter++;
                    }
                }
                Console.WriteLine($"Die Summe beträgt: {Summe}.");
            } while (MWiderholen() == true);
        }
        static bool MWiderholen()
        {
            string einlesen;
            bool widerholen;
            Console.Write("Wollen sie das Programm widerholen [j/N] : ");
            einlesen = Console.ReadLine().ToUpper();
            if (einlesen == "JA" || einlesen == "J")
            {
                widerholen = true;
            }
            else
            {
                widerholen = false;
            }
            return widerholen;
        }
        static string Input_String(string Name)
        {
            Console.WriteLine(Name);
            return Console.ReadLine();
        }
    }
}

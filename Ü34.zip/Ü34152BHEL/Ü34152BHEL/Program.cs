﻿using System;

namespace Ü34152BHEL
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Die Kosten betragen: {Kosten(Einlesen_OG_UG("Anschlussklasse", 2, 0))} Euro");
        }
        static int Einlesen_OG_UG(string Name, int OG, int UG)
        {//Einlesen einer ganzen Zahl im bereich größer-gleich UG und kleiner-gleich OG
            int Eingabe;
            do
            {
                Console.Write($"{Name} von {UG} bis {OG}: ");
                Eingabe = Convert.ToInt32(Console.ReadLine());
            } while (Eingabe < UG || Eingabe > OG);
            return Eingabe;
        }

        static double MEinlesen_inf(string Name, int UG)
        {
            double Eingabe;
            do
            {
                Console.Write($"Bitte geben sie die {Name} ein: ");
                Eingabe = Convert.ToDouble(Console.ReadLine());
            } while (Eingabe <= UG);
            return Eingabe;
        }

        static double Kosten(int Anschlussklasse)
        {
            double Betrag = 0, Onlinestunden, Übertragungsgeschwindigkeit;

            switch (Anschlussklasse)
            {
                case 0:
                    return 15;
                case 1:

                    Onlinestunden = MEinlesen_inf("Onlinestunden", 0);

                    if (Onlinestunden > 0)
                    {

                        Übertragungsgeschwindigkeit = MEinlesen_inf("Übertragungsgeschwindigkeit (in kBit/sek)", 0);

                        if (Übertragungsgeschwindigkeit <= 512)
                        {
                            return Onlinestunden;
                        }
                        else if (Übertragungsgeschwindigkeit < 1024)
                        {
                            return 1.5 * Onlinestunden;
                        }
                        else
                        {
                            return 2 * Onlinestunden;
                        }

                    }
                    break;
                case 2:

                    Onlinestunden = Einlesen_OG_UG("Onlinestunden", 1000, 0);

                    if (Onlinestunden > 0 && Onlinestunden <= 1000)
                    {
                        return 1.5 * Onlinestunden;
                    }
                    break;

            }

            return Betrag;
        }
    }
}

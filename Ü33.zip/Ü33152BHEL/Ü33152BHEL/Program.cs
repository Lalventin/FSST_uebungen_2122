﻿using System;

namespace Ü03152BHEL
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Xxx Dreieckbestimmung xxX");

            do
            {
                Console.WriteLine(MDreiecksbestimmung(MEinlesen_inf("Seite a", 0), MEinlesen_inf("Seite b", 0), MEinlesen_inf("Seite c", 0)));
            } while (MWiderholen() == true);

            Console.ReadLine();
        }
        static string MDreiecksbestimmung(double Seitea, double Seiteb, double Seitec)
        {
            if (Seitea >= (Seiteb + Seitec) || Seiteb >= (Seitea + Seitec) || Seitec >= (Seitea + Seiteb))
            {
                //ist kein Dreieck
                return "kein Dreieck";
            }
            else
            {
                //ist ein Dreieck
                if (Seitea == Seiteb && Seiteb == Seitec && Seitea == Seitec)
                {
                    //gleichseitig
                    return "gleichseitig";

                }
                else
                {
                    if (Seitea == Seiteb || Seiteb == Seitec || Seitea == Seitec)
                    {
                        //gleichschenkelig
                        if ((Math.Round((Math.Pow(Seitea, 2) + Math.Pow(Seiteb, 2)), 1) == Math.Round((Math.Pow(Seitec, 2)), 1) || Math.Round((Math.Pow(Seitea, 2) + Math.Pow(Seitec, 2)), 1) == Math.Round((Math.Pow(Seiteb, 2)), 1) || Math.Round((Math.Pow(Seiteb, 2) + Math.Pow(Seitec, 2)), 1) == Math.Round((Math.Pow(Seitea, 2)), 1)))
                        {
                            //gleichschenklig rechtwinklig
                            return "gleichschenklig rechtwinklig";
                        }
                        else
                        {
                            //nur gleichschenklig
                            return "gleichschenklig";
                        }
                    }
                    else
                    {
                        if ((Math.Round((Math.Pow(Seitea, 2) + Math.Pow(Seiteb, 2)), 1) == Math.Round((Math.Pow(Seitec, 2)), 1) || Math.Round((Math.Pow(Seitea, 2) + Math.Pow(Seitec, 2)), 1) == Math.Round((Math.Pow(Seiteb, 2)), 1) || Math.Round((Math.Pow(Seiteb, 2) + Math.Pow(Seitec, 2)), 1) == Math.Round((Math.Pow(Seitea, 2)), 1)))
                        {

                            //rechtwinklig
                            return "Rechtwinklig";

                        }
                        else
                        {
                            //allgemein
                            return "allgemeines Dreieck";
                        }


                    }
                }
            }
        }
        static double MEinlesen_inf(string Name, int UG)
        {
            double Eingabe;
            do
            {
                Console.Write($"Bitte geben sie die {Name} ein: ");
                Eingabe = Convert.ToDouble(Console.ReadLine());
            } while (Eingabe <= UG);
            return Eingabe;
        }
        static bool MWiderholen()
        {
            string einlesen;
            Console.Write("Wollen sie das Programm widerholen [j/N] : ");
            einlesen = Console.ReadLine().ToUpper();
            if (einlesen == "JA" || einlesen == "J")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

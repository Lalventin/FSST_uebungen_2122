﻿using System;

namespace Ü42152BHEL
{
    internal class Program
    {
        static void Main(string[] args)
        {//JISA
            int Zahl1 = 5, Zahl2 = 7, Zahl3 = 9;

            Console.WriteLine($"Zahl1: {Zahl1}");
            Console.WriteLine($"Zahl2: {Zahl2}");
            Console.WriteLine($"Zahl3: {Zahl3}");

            Austauschen(ref Zahl1, ref Zahl2);

            Console.WriteLine($"Zahlen nach austauschen");
            Console.WriteLine($"Zahl1: {Zahl1}");
            Console.WriteLine($"Zahl2: {Zahl2}");
            Console.WriteLine($"Zahl3: {Zahl3}");

            Mathematik(in Zahl1, in Zahl2);
            Quader(in Zahl1, in Zahl2, in Zahl3);

        }
        static void Austauschen(ref int Eingabe1, ref int Eingabe2)
        {
            int tmp = Eingabe1;
            Eingabe1 = Eingabe2;
            Eingabe2 = tmp;
        }
        static void Mathematik(in int Eingabe1, in int Eingabe2)
        {
            Console.WriteLine($"Summe: {Eingabe2 + Eingabe1}");
            Console.WriteLine($"Differenz: {Eingabe1 - Eingabe2}");
            Console.WriteLine($"Produkt: {Eingabe1 * Eingabe2}");
            Console.WriteLine($"Quotient: {(double)Eingabe1 / (double)Eingabe2 * 1.0}");
        }
        static void Quader(in int Eingabe1, in int Eingabe2, in int Eingabe3)
        {
            Console.WriteLine($"Volumen: {Eingabe1 * Eingabe2 * Eingabe3}");
            Console.WriteLine($"Oberfläche: {2 * (Eingabe3 * Eingabe2) + 2 * (Eingabe1 * Eingabe2) + 2 * (Eingabe1 * Eingabe3)}");
        }
    }
}

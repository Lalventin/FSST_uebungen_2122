﻿using System;

namespace Ü31152BHEL
{
    class Program
    {
        static void Main(string[] args)
        {
            double Länge, Breite;
            Console.WriteLine("Rechteck");
            do
            {
                Länge = MEinlesen("Länge");
                Breite = MEinlesen("Breite");
                Console.WriteLine($"Die Fläche Beträgt: {(Länge * Breite)}");
                Console.WriteLine($"Der Umfang Beträgt: {(2 * Länge + 2 * Breite)}");
            } while (MWiderholen() == true);
            Console.ReadLine();
            
        }
        static double MEinlesen(string Name)
        {
            double Eingabe;
            do
            {
                Console.Write($"Bitte geben sie die {Name} ein: ");
                Eingabe = Convert.ToDouble(Console.ReadLine());
            } while (Eingabe <= 0);
            return Eingabe;
        }
        static bool MWiderholen()
        {
            string einlesen;
            bool widerholen;
            Console.Write("Wollen sie das Programm widerholen [j/N] : ");
            einlesen = Console.ReadLine().ToUpper();
            if(einlesen == "JA" || einlesen == "J")
            {
                widerholen = true;
            }
            else
            {
                widerholen = false;
            }
            return widerholen;
        }
    }
}

﻿using System;
using System.IO;

namespace Ü52152BHEL
{
    internal class Program
    {
        static void Main(string[] args)
        {//JISA
            do
            {
                try
                {
                    Console.Write("Bitte geben sie den Dateipfad an: ");
                    Console.WriteLine(File.ReadAllText(Console.ReadLine()));
                }
                catch (PathTooLongException)
                {
                    Console.WriteLine("Pfad ist zu lang!");
                }
                catch (DirectoryNotFoundException)
                {
                    Console.WriteLine("Dateipfad existiert nicht!");
                }
                catch (FileNotFoundException)
                {
                    Console.WriteLine("Datei existier nicht!");
                }
                catch (NotSupportedException)
                {
                    Console.WriteLine("Datei hat das Falsche Format!");
                }
                catch (IOException)
                {
                    Console.WriteLine("Fehler!!");
                }
                catch{}
            } while (MWiderholen() == true);
            
            
            
        }
        static bool MWiderholen()
        {
            string einlesen;
            bool widerholen;
            Console.Write("Wollen sie das Programm widerholen [j/N] : ");
            einlesen = Console.ReadLine().ToUpper();
            if (einlesen == "JA" || einlesen == "J")
            {
                widerholen = true;
            }
            else
            {
                widerholen = false;
            }
            return widerholen;
        }
    }
}

﻿using System;

namespace Ü41152BHEL
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*** Rechteck ***");
            do
            {
                einleseninf("Länge", 0, out int Länge);
                einleseninf("Breite", 0, out int Breite);
                UmfangFläche(Länge, Breite);
            } while (MWiderholen() == true);
            
        }
        static void einleseninf(string Name, int UG, out int Eingabe)
        {
            do
            {
                Console.Write($"Bitte geben sie die {Name} ein: ");
                Eingabe = Convert.ToInt32(Console.ReadLine());
            } while (Eingabe <= UG);
        }
        static void UmfangFläche (int Länge, int Breite)
        {
            Console.WriteLine($"Der Umfang beträgt: {(2 * Länge + 2 * Breite)}.");
            Console.WriteLine($"Die Fläche beträgt: {(Länge*Breite)}.");
        }
        static bool MWiderholen()
        {
            string einlesen;
            bool widerholen;
            Console.Write("Wollen sie das Programm widerholen [j/N] : ");
            einlesen = Console.ReadLine().ToUpper();
            if (einlesen == "JA" || einlesen == "J")
            {
                widerholen = true;
            }
            else
            {
                widerholen = false;
            }
            return widerholen;
        }
    }
}

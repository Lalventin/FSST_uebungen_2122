﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMÜ_nutzerdefMeth_F
{
    class Program
    {//JISA
        /* Summe aller echten Teiler (ohne 1 und Zahl selbst) ausgeben
     z.B. von 60: TeilerSumme=107 (aus 2+3+4+5+6+10+12+15+20+30) */
        static int TeilerSumme(int Eingabe)
        {
            int teilersumme = 0;

            for(int i = 2; i < Eingabe; i++)
            {
                if(Eingabe % i == 0)
                {
                    teilersumme+= i;
                }
            }

            return teilersumme;

        }

        //Methode berechnet den Absolutbetrag einer ganzen Zahl
        static int Betrag(int Eingabe)
        {
            return Math.Abs(Eingabe);
        }

        static void Main(string[] args)
        {
            int a;
            Console.Write("Zahl: ");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(TeilerSumme(a));
            Console.WriteLine(Betrag(a));

        }
    }
}
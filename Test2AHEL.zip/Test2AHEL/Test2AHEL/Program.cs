﻿using System;

namespace Test2AHEL
{
    internal class Program
    {   //JISA
        static void Main(string[] args)
        {
            int Anzahl_Durchgänge;
            Console.WriteLine("**Sortieren**");
            Anzahl_Durchgänge = Einlesen_UGOG("Anzahl der Durchgänge (mindestens 3)", 3, int.MaxValue);
            int dritte_Zahl = 0;
            for (int i = 1; i <= Anzahl_Durchgänge; i++)
            {
                string ausgabe;
                int erste_Zahl = 0, zweite_Zahl = 0;

                Console.WriteLine($"Durchgang: {i}"); // Console.WriteLine("Durchgang" + i);

                erste_Zahl = Einlesen_UGOG("erste Zahl", 0, int.MaxValue);
                zweite_Zahl = Einlesen_UGOG("zweite Zahl", 0, int.MaxValue);

                Console.Write($"{dritte_Zahl} * {erste_Zahl} * {zweite_Zahl}");

                Zahlensortierung(erste_Zahl, zweite_Zahl, dritte_Zahl, out ausgabe, out dritte_Zahl);

                Console.WriteLine($"  {ausgabe}");

            }
            Console.WriteLine($"Der größte Wert ist: {dritte_Zahl}");
            Console.ReadLine();
        }
        static int Einlesen_UGOG(string Name, int UG, int OG)
        {
            int Eingabe = 0;
            do
            {
                Console.WriteLine("Bitte geben sie die " + Name + "ein: ");
                Eingabe = Convert.ToInt32(Console.ReadLine());
            }while(Eingabe < UG || Eingabe > OG);
            return Eingabe;
        }

        static void Zahlensortierung(int erste_Zahl, int zweite_Zahl, int dritte_Zahl, out string Ausgabe, out int größte_Zahl)
        {
            Ausgabe = "Error";
            größte_Zahl = 0;
            
            while(erste_Zahl > zweite_Zahl || zweite_Zahl > dritte_Zahl || erste_Zahl > dritte_Zahl)
            {
                if(erste_Zahl > zweite_Zahl)
                {
                    Sortieren_2Zahlen(ref erste_Zahl, ref zweite_Zahl);
                }
                if (zweite_Zahl > dritte_Zahl)
                {
                    Sortieren_2Zahlen(ref zweite_Zahl, ref dritte_Zahl);
                }

            }
            if (erste_Zahl <= zweite_Zahl && zweite_Zahl <= dritte_Zahl && erste_Zahl <= dritte_Zahl)
            {
                Ausgabe = $"{erste_Zahl} + {zweite_Zahl} + {dritte_Zahl}";
                größte_Zahl = dritte_Zahl;
            }


        }
        static void Sortieren_2Zahlen(ref int Eingabe1, ref int Eingabe2)
        {
            if(Eingabe1 < Eingabe2)
            {
                return;
            }
            else
            {
                int temp;
                temp = Eingabe1;
                Eingabe1 = Eingabe2;
                Eingabe2 = temp;
            }
        }

    }
}

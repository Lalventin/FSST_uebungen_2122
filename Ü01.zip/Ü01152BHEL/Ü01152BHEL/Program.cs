﻿using System;

namespace Ü01152BHEL
{
    class Program
    {
        static void Main(string[] args)
        {
            double Länge, Breite, Umfang, Fläche;

            Console.WriteLine("Xxx Rechteck xxX");
            Console.Write("Bitte geben sie die Länge ein: ");
            Länge = Convert.ToDouble(Console.ReadLine());
            if(Länge > 0)
            {
                Console.Write("Geben sie die Breite an: ");
                Breite = Convert.ToDouble(Console.ReadLine());
                if(Breite > 0)
                {
                    Umfang = (2 * Länge) + (2 * Breite);
                    Fläche = Länge * Breite;
                    Console.WriteLine("Der Umfang beträgt: " + Umfang + " m.");
                    Console.WriteLine("Die Fläche beträgt: " + Fläche + " m².");
                }
                else
                {
                    Console.WriteLine("Breite muss größer als 0 sein!!");
                }
            }
            else
            {
                Console.WriteLine("Länge muss größer als 0 sein!");
            }
            Console.ReadLine();
        }
    }
}

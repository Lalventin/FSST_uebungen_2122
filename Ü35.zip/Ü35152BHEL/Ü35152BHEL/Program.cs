﻿using System;

namespace Ü15152BHEL
{
    class Program
    {
        static void Main(string[] args)
        {   

            Console.WriteLine("Xxx Skispringen xxX");

            int Sprungweite_ganz;
            double[] Richterbewertung = new double[5];

            Einlesen(out Richterbewertung, out Sprungweite_ganz);
            Punkteberechnung(Richterbewertung, Sprungweite_ganz);


            Console.ReadLine();

        }
        static int Punkteberechnung(double[] Richterbewertung, int Sprungweite_ganz)
        {
            double Punkte_Sprungweite, Sprungweite_differenz, Endpunkte = 0;
            Array.Sort(Richterbewertung);
            Richterbewertung[0] = 0;    //entfernen des min und max wertes
            Richterbewertung[4] = 0;

            Sprungweite_differenz = (90 - Sprungweite_ganz) * 1.2;
            Punkte_Sprungweite = 90 - Sprungweite_differenz;

            for (int j = 0; j <= 4; j++)
            {
                Endpunkte += Richterbewertung[j];
            }
            Endpunkte += Punkte_Sprungweite;
            Console.WriteLine("Die Gesamtwertung beträgt: " + Endpunkte);
            return 0;
        }
        static void Einlesen(out double[] Richterbewertung, out int Sprungweite_ganz)
        {
            Richterbewertung = new double[5];
            double Sprungweite;
            do
            {
                Console.Write("Sprungweite: ");
                Sprungweite = Convert.ToDouble(Console.ReadLine());
                Sprungweite_ganz = Convert.ToInt32(Sprungweite);
            } while (Sprungweite_ganz < 0 || Sprungweite_ganz > 150);

            for (int i = 1; i <= 5; i++)
            {
                do
                {
                    Console.Write("Sprungrichter " + i + ": ");
                    Richterbewertung[i - 1] = Convert.ToDouble(Console.ReadLine());
                    Richterbewertung[i - 1] = Math.Round(Richterbewertung[i - 1]);

                } while (Richterbewertung[i - 1] < 0 || Richterbewertung[i - 1] > 20);
            }
        }
    }
}

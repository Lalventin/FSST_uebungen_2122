﻿using System;

namespace Test1152BHEL
{
    class Program
    {
        static void Main(string[] args)
        {

            double Betrag, Onlinestunden, Übertragungsgeschwindigkeit;
            int Anschlussklasse;

            Console.WriteLine("*** Fa. Inet: Internetzugänge ***");

            do
            {
                Console.Write("Anschlussklasse (0/1/2): ");
                Anschlussklasse = Convert.ToInt32(Console.ReadLine());
            } while (Anschlussklasse < 0);

            if(Anschlussklasse >= 0 && Anschlussklasse <= 2)
            {
                switch (Anschlussklasse)
                {
                    case 0:

                        Betrag = 15;
                        Console.WriteLine("Der Rechnungsbetrag beträgt " + Betrag + "Euro.");


                        break;
                    case 1:

                        do
                        {
                            Console.Write("Onlinestunden: ");
                            Onlinestunden = Convert.ToDouble(Console.ReadLine());
                        } while (Onlinestunden <= 0);

                        if(Onlinestunden > 0)
                        {

                            do
                            {
                                Console.Write("Übertragungsgeschwindigkeit (in kBit/sek): ");
                                Übertragungsgeschwindigkeit = Convert.ToDouble(Console.ReadLine());
                            } while (Übertragungsgeschwindigkeit <= 0);



                            if(Übertragungsgeschwindigkeit <= 0)
                            {
                                Console.WriteLine("Die Übertragungsgeschwindigkeit muss größer als 0 sein!!!");     //nicht im Struktogramm eingezeichnet!!!
                                                                                                                    // musste aber noch Fehlermeldung bei flascher Eingabe hinzufügen.
                            }
                            else if(Übertragungsgeschwindigkeit <= 512)
                            {
                                Betrag = Onlinestunden;

                                Console.WriteLine("Der Rechnungsbetrag beträgt " + Betrag + "Euro.");

                            }
                            else if(Übertragungsgeschwindigkeit < 1024)
                            {
                                Betrag = 1.5 * Onlinestunden;

                                Console.WriteLine("Der Rechnungsbetrag beträgt " + Betrag + "Euro.");

                            }
                            else
                            {
                                Betrag = 2 * Onlinestunden;

                                Console.WriteLine("Der Rechnungsbetrag beträgt " + Betrag + "Euro.");

                            }

                        }
                        else
                        {
                            Console.WriteLine("die Anzahl der Onlinestunden muss größer als 0 sein!!!");
                        }


                        break;
                    case 2:

                        do
                        {
                            Console.Write("Onlinestunden: ");
                            Onlinestunden = Convert.ToDouble(Console.ReadLine());
                        } while (Onlinestunden <= 0);

                        if(Onlinestunden > 0 && Onlinestunden <= 1000)
                        {

                            Betrag = 1.5 * Onlinestunden;

                            Console.WriteLine("Der Rechnungsbetrag beträgt " + Betrag + "Euro.");


                        }
                        else
                        {
                            Console.WriteLine("Die Anzahl der Onlinestunden muss größer als 0 und kleiner als 1000 sein!!!");
                        }

                        break;

                }
            }
            else
            {
                Console.WriteLine("Bitte geben sie eine Verfügbare Anschlussklasse an!!!");

            }
            Console.ReadLine();


            
        }
    }   
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ü55152BHEL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if(rb1.IsChecked == true)
            {
                possible();
            }
            else if(rb2.IsChecked == true)
            {
                try
                {
                    int Hangneigung = Convert.ToInt32(tb3.Text);
                    if (Hangneigung < 40 && Hangneigung >= 0)
                    {
                        possible();
                    }
                    else
                    {
                        not_possible();
                    }
                }
                catch (Exception ex)
                {
                    Error();
                }
            }
            else if(rb3.IsChecked == true)
            {
                try
                {
                    int Hangneigung = Convert.ToInt32(tb3.Text);
                    if (Hangneigung < 35 && Hangneigung >= 0 && Convert.ToInt32(tb1.Text) < 11 && Convert.ToInt32(tb1.Text) >= 0 && cb1.IsChecked == false)
                    {
                        possible();
                    }
                    else
                    {
                        not_possible();
                    }
                }
                catch (Exception ex)
                {
                    Error();
                }
            }
            if(rb4.IsChecked == true)
            {
                try
                {
                    int Hangneigung = Convert.ToInt32(tb3.Text);
                    if (Hangneigung < 30 && Hangneigung >= 0 && Convert.ToInt32(tb1.Text) < 10 && Convert.ToInt32(tb1.Text) >= 0 && cb1.IsChecked == false)
                    {
                        possible();
                    }
                    else
                    {
                        not_possible();
                    }
                }
                catch (Exception ex)
                {
                    Error();
                }
            }
            else if(rb5.IsChecked == true)
            {
                not_possible();
            }
        }
        private void possible() {
            lbl4.Foreground = System.Windows.Media.Brushes.Green;
            lbl4.Content = "Skitour ist möglich";
        }
        private void not_possible()
        {
            lbl4.Foreground = System.Windows.Media.Brushes.Red;
            lbl4.Content = "Skitour ist nicht möglich";
        }
        private void Error()
        {
            lbl4.Foreground = System.Windows.Media.Brushes.Red;
            lbl4.Content = "Fehler!";
        }
    }
}

﻿using System;

namespace Ü03152BHEL
{
    class Program
    {
        static void Main(string[] args)
        {
            double Seitea, Seiteb, Seitec;
            string antwort;

            Console.WriteLine("Xxx Dreieckbestimmung xxX");

            do {

                do
                {
                    Console.Write("Bitte geben sie die Seite a an: ");
                    Seitea = Convert.ToDouble(Console.ReadLine());
                } while (Seitea <= 0);

                do
                {
                    Console.Write("Bitte geben sie die Seite b an: ");
                    Seiteb = Convert.ToDouble(Console.ReadLine());
                } while (Seiteb <= 0);

                do
                {
                    Console.Write("Bitte geben sie die Seite c an: ");
                    Seitec = Convert.ToDouble(Console.ReadLine());
                } while (Seitec <= 0);

                if (Seitea >= (Seiteb + Seitec) || Seiteb >= (Seitea + Seitec) || Seitec >= (Seitea + Seiteb))
                {
                    //ist kein Dreieck
                    Console.WriteLine("Kein Dreieck!!!");
                }
                else
                {
                    //ist ein Dreieck
                    if (Seitea == Seiteb && Seiteb == Seitec && Seitea == Seitec)
                    {
                        //gleichseitig
                        Console.WriteLine("gleichseitig");

                    }
                    else
                    {
                        if (Seitea == Seiteb || Seiteb == Seitec || Seitea == Seitec)
                        {
                            //gleichschenkelig
                            if ((Math.Round((Math.Pow(Seitea, 2) + Math.Pow(Seiteb, 2)), 1) == Math.Round((Math.Pow(Seitec, 2)), 1) || Math.Round((Math.Pow(Seitea, 2) + Math.Pow(Seitec, 2)), 1) == Math.Round((Math.Pow(Seiteb, 2)), 1) || Math.Round((Math.Pow(Seiteb, 2) + Math.Pow(Seitec, 2)), 1) == Math.Round((Math.Pow(Seitea, 2)), 1)))
                            {
                                //gleichschenklig rechtwinklig
                                Console.WriteLine("gleichschenklig rechtwinklig");
                            }
                            else
                            {
                                //nur gleichschenklig
                                Console.WriteLine("gleichschenklig");
                            }
                        }
                        else
                        {
                            if ((Math.Round((Math.Pow(Seitea, 2) + Math.Pow(Seiteb, 2)), 1) == Math.Round((Math.Pow(Seitec, 2)), 1) || Math.Round((Math.Pow(Seitea, 2) + Math.Pow(Seitec, 2)), 1) == Math.Round((Math.Pow(Seiteb, 2)), 1) || Math.Round((Math.Pow(Seiteb, 2) + Math.Pow(Seitec, 2)), 1) == Math.Round((Math.Pow(Seitea, 2)), 1)))
                            {

                                //rechtwinklig
                                Console.WriteLine("Rechtwinklig");

                            }
                            else
                            {
                                //allgemein
                                Console.WriteLine("allgemeines Dreieck");
                            }


                        }
                    }
                }

                Console.Write("Möchten sie das Programm widerholen [j/N] :");
                antwort = Console.ReadLine();
                antwort = antwort.ToUpper();


            } while (antwort == "JA" || antwort == "J");

            Console.ReadLine();
        }
    }
}

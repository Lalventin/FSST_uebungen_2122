﻿using System;

namespace Ü20152BHEL
{
    class Program
    {
        static void Main(string[] args)
        { 
            int Teiler, Start, Ende;
            string antwort;
            Console.WriteLine("Xxx Zahlenbereich mit *");

            do
            {
                do
                {
                    Console.Write("Bitte geben sie den Teiler ein: ");
                    Teiler = Convert.ToInt32(Console.ReadLine());
                } while (Teiler < 2 || Teiler > 100);

                do
                {
                    Console.Write("Bitte geben sie den Start ein: ");
                    Start = Convert.ToInt32(Console.ReadLine());
                } while (Start < 10 || Start > 1000);

                do
                {
                    Console.Write("Bitte geben sie das Ende ein: ");
                    Ende = Convert.ToInt32(Console.ReadLine());
                } while (Ende < (Start + 1) || Ende > 1500);

                for(int i = 0; i<=Ende; i++)
                {

                    if((i%Teiler) == 0)
                    {
                        Console.WriteLine("*");
                    }
                    else
                    {
                        Console.WriteLine(i);
                    }

                }


                Console.Write("Wollen sie das Programm widerholen [N/j] : ");
                antwort = Console.ReadLine();
                antwort = antwort.ToUpper();
            } while (antwort == "JA" || antwort == "J");
        }
    }
}

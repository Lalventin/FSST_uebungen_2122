﻿using System;

namespace Ü28152BHEL
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] Notennamen = new string[7];//definition Schulfächer
            Notennamen[0] = "Deutschnote";
            Notennamen[1] = "Mathematiknote";
            Notennamen[2] = "Englischnote";
            Notennamen[3] = "Hardwareentwicklung";
            Notennamen[4] = "Fachspezifische Software Technik";
            Notennamen[5] = "Religion";
            Notennamen[6] = "Bewegung und Sport";

            double Durchschnitt_Schüler;
            int[] Klassendurchschnitte = new int[7];//gleiche Fächerreihenfolge wie bei "Notennamen"
            for(int x = 0; x <=6; x++)
            {
                Klassendurchschnitte[x] = 0;
            }
            string[,] Namen_Schüler = new string[36, 2]; //Zeile 0: Nachname, Zeile 1: Vorname
            int Anzahl_Schüler, Durchschnitt_Schüler_Berechnung, Durchschnitt_Schüler_Tmp;
            string antwort;
            do
            {
                for (int x = 0; x <= 6; x++)
                {
                    Klassendurchschnitte[x] = 0;
                }

                Durchschnitt_Schüler_Berechnung = 0;
                do//Abfrage Schüleranzahl
                {
                    Console.Write("Bitte geben sie die Anzahl der Schüler ein: ");
                    Anzahl_Schüler = Convert.ToInt32(Console.ReadLine());
                } while (Anzahl_Schüler < 0 || Anzahl_Schüler > 36);

                for(int Schüler_index = 0; Schüler_index<Anzahl_Schüler; Schüler_index++)
                {

                    Console.WriteLine("Geben sie bitte die Datei für Schüler Katalog Nr. " + (Schüler_index + 1) + "ein: ");
                    Console.Write("Familienname: ");
                    Namen_Schüler[Schüler_index, 0] = Console.ReadLine();
                    Console.Write("Vorname: ");
                    Namen_Schüler[Schüler_index, 1] = Console.ReadLine();
                    for(int Notenindex = 0; Notenindex<=6; Notenindex++)
                    {
                        do
                        {                            
                            Console.Write(Notennamen[Notenindex] + " : ");//eingabeaufforderung Note 
                            Durchschnitt_Schüler_Tmp = Convert.ToInt32(Console.ReadLine());//einlesen Note
                            
                        } while (Durchschnitt_Schüler_Tmp <= 0 || Durchschnitt_Schüler_Tmp > 5);
                        Durchschnitt_Schüler_Berechnung += Durchschnitt_Schüler_Tmp; //berechnung Durchschnitt des Schülers
                        Klassendurchschnitte[Notenindex] += Durchschnitt_Schüler_Tmp;//Speichern Klassendurchschnitte bei Fach i
                    }
                    Durchschnitt_Schüler = Convert.ToDouble(Durchschnitt_Schüler_Berechnung) / 7.0;//berechnen Durchschnitt Schüler
                    Console.WriteLine("Der Durchschnitt von Katalognummer: " + (Schüler_index + 1) + " " + Namen_Schüler[Schüler_index, 0] + " " + Namen_Schüler[Schüler_index, 1] + " beträgt: " + Durchschnitt_Schüler);
                    Durchschnitt_Schüler = 0;
                    Durchschnitt_Schüler_Berechnung = 0;
                }                
                for (int y = 0; y <= 6; y++)
                {
                    Console.WriteLine("Der Notendurchschnitt in " + Notennamen[y] + " beträgt für die Klasse: " + ((double)Klassendurchschnitte[y]/(double)Anzahl_Schüler));
                }


                
                Console.Write("Wollen sie das Programm widerholen [n/J]: ");
                antwort = Console.ReadLine();
                antwort = antwort.ToUpper();
            } while (antwort == "JA" || antwort == "J");


        }
    }
}

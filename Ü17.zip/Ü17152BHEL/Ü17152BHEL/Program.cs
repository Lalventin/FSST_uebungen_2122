﻿using System;

namespace Ü17152BHEL
{
    class Program
    {
        static void Main(string[] args)
        {

            double Eingabe, Durchschnitt_A, Durchschnitt_B;
            string antwort;
            do
            {
                Durchschnitt_A = 0;
                Durchschnitt_B = 0;
                for(int i = 1; i <= 3; i++)
                {
                    do
                    {
                        Console.Write("Wertungsrichter " + i +  " Note A: ");
                        Eingabe = Math.Round(Convert.ToDouble(Console.ReadLine()), 1);
                    } while (Eingabe < 0 || Eingabe > 10);
                    Durchschnitt_A += Eingabe;
                }
                for (int i = 1; i <= 3; i++)
                {
                    do
                    {
                        Console.Write("Wertungsrichter " + i + " Note B: ");
                        Eingabe = Math.Round(Convert.ToDouble(Console.ReadLine()), 1);
                    } while (Eingabe < 0 || Eingabe > 10);
                    Durchschnitt_B += Eingabe;
                }
                Durchschnitt_A = Durchschnitt_A / 3;
                Durchschnitt_B = Durchschnitt_B / 3;

                Console.WriteLine("Das Ergebnis der A-Note beträgt: " + Durchschnitt_A);
                Console.WriteLine("Das Ergebnis der B-Note beträgt: " + Durchschnitt_B);

                Console.Write("Wollen sie das Programm widerholen [j/N]: ");
                antwort = Console.ReadLine();
                antwort = antwort.ToUpper();
                
            } while (antwort == "J" || antwort == "JA");

        }
    }
}

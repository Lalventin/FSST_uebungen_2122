﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMÜ_nutzerdefMeth_G
{
    class Program
    {//JISA
        /* Methode sortiert die zwei Eingabeparameter der Größe nach;
         nach der Methode, muss der erste Parameter den kleineren Wert erhalten */
        static void Sort(ref int Eingabe1, ref int Eingabe2)
        {
            if (Eingabe2 < Eingabe1)
            {
                int temp;
                temp = Eingabe1;
                Eingabe1 = Eingabe2;
                Eingabe2 = temp;
            }
        }

        // bestimmt, ob die Zahl eine Primzahl ist oder nicht
        static bool Prim(int number)
        {
            if (number <= 1) return false;
            if (number == 2) return true;
            if (number % 2 == 0) return false;

            var boundary = (int)Math.Floor(Math.Sqrt(number));

            for (int i = 3; i <= boundary; i += 2)
                if (number % i == 0)
                    return false;

            return true;
        }

        static void Main(string[] args)
        {
            int z1, z2;

            Console.Write("Zahl1: ");
            z1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Zahl2: ");
            z2 = Convert.ToInt32(Console.ReadLine());

            Sort(ref z1, ref z2);
            if(Prim(z1) == true)
            {
                Console.WriteLine($"{z1} is a prime number");
            }
            else
            {
                Console.WriteLine($"{z1} is not a prime number");
            }

        }
    }
}

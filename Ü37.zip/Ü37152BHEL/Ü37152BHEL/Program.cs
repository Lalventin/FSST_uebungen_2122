﻿using System;

namespace Ü37152BHEL
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double Durchschnitt_A, Durchschnitt_B;

            do
            {
                Durchschnitt_A = 0;
                Durchschnitt_B = 0;

                for (int i = 1; i <= 3; i++)
                {
                    Durchschnitt_A += Einlesen_OGUG($"Wertungsrichter {i} Note A: ", 0, 10);
                }
                for (int i = 1; i <= 3; i++)
                {
                    Durchschnitt_B += Einlesen_OGUG($"Wertungsrichter {i} Note B: ", 0, 10);
                }
                Durchschnitt_A = Durchschnitt_A / 3.0;
                Durchschnitt_B = Durchschnitt_B / 3.0;

                Console.WriteLine("Das Ergebnis der A-Note beträgt: " + Durchschnitt_A);
                Console.WriteLine("Das Ergebnis der B-Note beträgt: " + Durchschnitt_B);
            } while (MWiderholen() == true);
        }
        static int Einlesen_OGUG(string Name, int UG, int OG)
        {
            int Eingabe;
            do
            {
                Console.Write($"Bitte geben sie die {Name} ein: ");
                Eingabe = Convert.ToInt32(Console.ReadLine());
            } while (Eingabe < UG ||
            Eingabe > OG);
            return Eingabe;
        }
        static bool MWiderholen()
        {
            string einlesen;
            bool widerholen;
            Console.Write("Wollen sie das Programm widerholen [j/N] : ");
            einlesen = Console.ReadLine().ToUpper();
            if (einlesen == "JA" || einlesen == "J")
            {
                widerholen = true;
            }
            else
            {
                widerholen = false;
            }
            return widerholen;
        }
    }
}

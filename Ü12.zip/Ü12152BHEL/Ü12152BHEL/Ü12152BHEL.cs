﻿using System;



namespace _2021_2A_Ü01
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("Xxx Skitour xxX");

            int lawinenStufe;
            int hangNeigung = 0;
            bool sonne = false;
            bool uhrzeit = false;
            int startzeit;
            string antwort;

            do {
                


                do
                {

                    Console.Write("Lawinenstufe=");
                    lawinenStufe = Convert.ToInt32(Console.ReadLine());
                } while (lawinenStufe <= 0);





                if (lawinenStufe >= 2 && lawinenStufe <= 4)
                {
                    do
                    {
                        Console.Write("Hangneigung (Grad): ");
                        hangNeigung = Convert.ToInt32(Console.ReadLine());

                    } while (hangNeigung <= 0 || hangNeigung > 90);
                }
                if (lawinenStufe == 3 || lawinenStufe == 4)
                {
                    Console.Write("Scheint die Sonne (j/n):");    // do while schleife hier nicht logisch weil der nutzer jeden string eingeben kann
                    antwort = Console.ReadLine();          // ohne dass es "falsch" ist, weil ja alles andere als "ja" und ähnliches
                    sonne = antwort == "j" || antwort == "J"        // automatisch als "nein" interpretiert wird
                        || antwort == "ja" || antwort == "JA"
                        || antwort == "Ja";
                    if (lawinenStufe == 3)
                    {
                        startzeit = 11;
                    }
                    else
                    {
                        startzeit = 10;
                    }
                    Console.Write("Startet die Tour vor " + startzeit
                        + ":00 Uhr (j/n): ");
                    antwort = Console.ReadLine();
                    uhrzeit = antwort == "j" || antwort == "J"          // do while schleife hier nicht logisch weil der nutzer jeden string eingeben kann
                        || antwort == "ja" || antwort == "JA"           // ohne dass es "falsch" ist, weil ja alles andere als "ja" und ähnliches
                        || antwort == "Ja";                             // automatisch als "nein" interpretiert wird
                }

                switch (lawinenStufe)
                {
                    case 1:
                        Console.WriteLine("JA, du kannst fahren");
                        break;
                    case 2:
                        if (hangNeigung < 40)
                        {
                            Console.WriteLine("JA, du kannst fahren");
                        }
                        else
                        {
                            Console.WriteLine("Nein, keine Abfahrt!");
                        }
                        break;
                    case 3:
                        if (hangNeigung < 35 && uhrzeit && !sonne)
                        {
                            Console.WriteLine("JA, du kannst fahren");
                        }
                        else
                        {
                            Console.WriteLine("Nein, keine Abfahrt!");
                        }
                        break;
                    case 4:
                        if (hangNeigung < 30 && uhrzeit && !sonne)
                        {
                            Console.WriteLine("JA, du kannst fahren");
                        }
                        else
                        {
                            Console.WriteLine("Nein, keine Abfahrt!");
                        }
                        break;
                    case 5:
                        Console.WriteLine("Nein, keine Abfahrt!");
                        break;
                    default:
                        Console.WriteLine("Bitte eine Zahl im Bereich von 1 bis 5 eingeben");
                        break;
                }


                Console.Write("Möchten sie das Programm widerholen [j/N] : ");
                antwort = Console.ReadLine();
                antwort = antwort.ToUpper();
                

            } while (antwort == "JA" || antwort == "J");

               Console.ReadLine();
        }
    }
}

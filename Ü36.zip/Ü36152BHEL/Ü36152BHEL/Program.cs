﻿using System;

namespace Ü36152BHEL
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Summe, Zahl;
            do
            {
                Summe = 0;
                for (int i = 0; i <= 5; i++)
                {
                    Zahl = MEinlesen_inf("Zahl", 0);
                    if (Zahl == 0)
                    {
                        break;
                    }
                    Summe += Zahl;
                    
                }
                Console.WriteLine("Die Summe ist: " + Summe);

            } while (MWiderholen() == true);
        }
        static int MEinlesen_inf(string Name, int UG)
        {
            int Eingabe;
            do
            {
                Console.Write($"Bitte geben sie die {Name} ein: ");
                Eingabe = Convert.ToInt32(Console.ReadLine());
            } while (Eingabe < UG);
            return Eingabe;
        }
        static bool MWiderholen()
        {
            string einlesen;
            bool widerholen;
            Console.Write("Wollen sie das Programm widerholen [j/N] : ");
            einlesen = Console.ReadLine().ToUpper();
            if (einlesen == "JA" || einlesen == "J")
            {
                widerholen = true;
            }
            else
            {
                widerholen = false;
            }
            return widerholen;
        }
    }
}

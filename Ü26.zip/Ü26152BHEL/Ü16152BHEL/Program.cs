﻿using System;

namespace Ü16152BHEL
{
    class Program
    {
        static void Main(string[] args)
        {
          

            Console.WriteLine("Xxx Summe xxX");
            string antwort;
            int Zahl;
            int Summe;
            do
            {
                Summe = 0;
                for (int i = 1; i <= 5; i++)
                {
                    do
                    {
                        Console.Write("Bite geben sie die " + i + "te Zahl ein: ");
                        Zahl = Convert.ToInt32(Console.ReadLine());
                    } while (Zahl < 0);

                    if (Zahl == 0)
                    {
                        break;
                    }

                    Summe += Zahl;
                }
                Console.WriteLine("Die Summe ist: " + Summe);
                Console.Write("Wollen sie das Programm widerholen [j/N]: ");
                antwort = Console.ReadLine();
                antwort = antwort.ToUpper();
            }
            while (antwort == "J" || antwort == "JA");
            Console.ReadLine();
        }
    }
}
